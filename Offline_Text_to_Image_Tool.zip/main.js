
function generateImage() {
  const prompt = document.getElementById('prompt').value;
  const loader = document.getElementById('loader');
  const result = document.getElementById('result');
  
  if (!prompt) {
    alert("Please enter a prompt");
    return;
  }

  loader.classList.remove('hidden');
  result.innerHTML = '';

  // 🔧 Simulated placeholder result (replace this with real WASM logic later)
  setTimeout(() => {
    loader.classList.add('hidden');
    result.innerHTML = `<img src="https://placehold.co/600x400?text=${encodeURIComponent(prompt)}" alt="Generated Image" />`;
  }, 2000);
}
